Cara Install
$ apt update && apt upgrade
$ apt install bash toilet
$ git clone https://github.com/XniceCraft/Sadap-Whatsapp-Via-Termux/
$ cd Sadap-Whatsapp-Via-Termux
$ sh sadapwhatsapp.sh
