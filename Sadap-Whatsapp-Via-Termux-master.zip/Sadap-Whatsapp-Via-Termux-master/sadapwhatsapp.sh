#!/bin/bash
echo Sedang Meloading
sleep 1
toilet -f small --gay Hack WA
echo "1.Sadap WA dengan Nomor HP"
echo "2.Sadap WA Dengan Phising"
read tipu

if [ $tipu = 1 ] || [ $tipu = 1 ]
then 
sleep 1
echo "Lu Kena Tipu Wkkwkwkkwk Sabar Bosque"
fi
exit

if [ $tipu = 2 ] || [ $tipu = 2 ]
then
echo "Mau Aja lu ditipu wkkwkwkwkwk"
fi 
exit
